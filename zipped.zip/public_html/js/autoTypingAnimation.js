setTimeout(function() {
    $('.about-info-inner').typed({
      strings: [
        "<span>Hi, I am Thirumalai Nagalingam</span><br> An aspiring and energetic individual who excels at motivating both himself and others. I am passionate about project implementation and launch and have the ability to translate business requirements into technical solutions.<br><br> I'm looking to begin a career as an entry-level software engineer with a reputable technology-driven firm. to work in an organization that provides me with numerous opportunities to improve my skills and knowledge while also contributing to the organization's growth. "
      ],
      typeSpeed: 10,
      contentType: 'html'
    });
  }, 100);